import requests
import time
import math

URL = "http://127.0.0.1:7125/printer/gcode/script"

def send_block(cmds):
    requests.post(URL, json={"script": "\n".join(cmds)})


# INIT
send_block(["FIRMWARE_RESTART"])
time.sleep(2)

send_block([
    "MANUAL_STEPPER STEPPER=m0 GCODE_AXIS=A",
    "MANUAL_STEPPER STEPPER=m1 GCODE_AXIS=B",
    "MANUAL_STEPPER STEPPER=m2 GCODE_AXIS=C",
    "MANUAL_STEPPER STEPPER=m3 GCODE_AXIS=D",
    "G90"
])

time.sleep(0.5)


# SMOOTH IDENTICAL MOTION
t = 0.0

AMPLITUDE = 3
POINTS = 200
STEP = 0.02
FEED = 30000

while True:
    cmds = []

    for i in range(POINTS):
        pos = AMPLITUDE * math.sin(t)

        # 🔥 SAME VALUE to all motors
        cmds.append(f"G1 A{pos:.2f} B{pos:.2f} C{pos:.2f} D{pos:.2f} F{FEED}")

        t += STEP

    send_block(cmds)
    
