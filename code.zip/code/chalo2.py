import requests
import time
import math

URL = "http://127.0.0.1:7125/printer/gcode/script"

def send_block(cmds):
    r = requests.post(
        URL,
        json={"script": "\n".join(cmds)}
    )

    print(r.text)


# =========================================================
# INIT
# =========================================================
send_block(["FIRMWARE_RESTART"])
time.sleep(3)

send_block([
    # fake homing so Klipper thinks machine is homed
    "SET_KINEMATIC_POSITION X=0 Y=0 Z=0",

    "G90",
    "G92 X0 Y0 Z0",

    # enable motors
    "SET_STEPPER_ENABLE STEPPER=stepper_x ENABLE=1",
    "SET_STEPPER_ENABLE STEPPER=stepper_x1 ENABLE=1",
    "SET_STEPPER_ENABLE STEPPER=stepper_x2 ENABLE=1",

    "SET_STEPPER_ENABLE STEPPER=stepper_y ENABLE=1",
    "SET_STEPPER_ENABLE STEPPER=stepper_y1 ENABLE=1",
    "SET_STEPPER_ENABLE STEPPER=stepper_y2 ENABLE=1",

    "SET_STEPPER_ENABLE STEPPER=stepper_z ENABLE=1",
    "SET_STEPPER_ENABLE STEPPER=stepper_z1 ENABLE=1",
])

time.sleep(1)


# =========================================================
# PARAMETERS
# =========================================================
AMPLITUDE = 3.0
POINTS = 200
STEP = 0.03
FEED = 3000
CHUNK = 20

t = 0.0


# =========================================================
# LOOP
# =========================================================
while True:

    cmds = []

    for i in range(POINTS):

        x = AMPLITUDE * math.sin(t)
        y = AMPLITUDE * math.sin(t + math.pi/2)
        z = AMPLITUDE * math.sin(t + math.pi)

        # synchronized planner move
        cmds.append(
            f"G1 X{x:.4f} Y{y:.4f} Z{z:.4f} F{FEED}"
        )

        t += STEP

        # send smaller chunks
        if len(cmds) >= CHUNK:
            send_block(cmds)
            cmds = []

    if cmds:
        send_block(cmds)

    time.sleep(0.01)
