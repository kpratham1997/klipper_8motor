import requests
import time
import math

URL = "http://127.0.0.1:7125/printer/gcode/script"

def send(cmd):
    requests.post(URL, json={"script": cmd})


# INIT
send("FIRMWARE_RESTART")
time.sleep(2)

send("""
MANUAL_STEPPER STEPPER=m0 GCODE_AXIS=A
MANUAL_STEPPER STEPPER=m1 GCODE_AXIS=B
MANUAL_STEPPER STEPPER=m2 GCODE_AXIS=C
MANUAL_STEPPER STEPPER=m3 GCODE_AXIS=D
MANUAL_STEPPER STEPPER=m4 GCODE_AXIS=U
MANUAL_STEPPER STEPPER=m5 GCODE_AXIS=V
MANUAL_STEPPER STEPPER=m6 GCODE_AXIS=W
MANUAL_STEPPER STEPPER=m7 GCODE_AXIS=X
G90
""")

time.sleep(1)


t = 0.0
AMPLITUDE = 5
STEP = 0.2      # 🔥 BIGGER step (less commands)
FEED = 20000

while True:
    pos = AMPLITUDE * math.sin(t)

    cmd = (
        f"G1 A{pos:.2f} B{pos:.2f} C{pos:.2f} D{pos:.2f} "
        f"U{pos:.2f} V{pos:.2f} W{pos:.2f} X{pos:.2f} F{FEED}"
    )

    send(cmd)

    t += STEP
    time.sleep(0.03)   # 🔥 CRITICAL: pacing
