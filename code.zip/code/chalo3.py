import requests
import time
import math

URL = "http://127.0.0.1:7125/printer/gcode/script"


def send_block(cmds):
    r = requests.post(
        URL,
        json={"script": "\n".join(cmds)}
    )

    print(r.text)


# =========================================================
# INIT
# =========================================================
send_block(["FIRMWARE_RESTART"])
time.sleep(3)

send_block([
    # fake homing
    "SET_KINEMATIC_POSITION X=0 Y=0 Z=0",

    "G90",
    "G92 X0 Y0 Z0",

    # smoother synchronized motion
    "SET_VELOCITY_LIMIT ACCEL=500",
    "SET_VELOCITY_LIMIT SQUARE_CORNER_VELOCITY=1",

    # enable motors
    "SET_STEPPER_ENABLE STEPPER=stepper_x ENABLE=1",
    "SET_STEPPER_ENABLE STEPPER=stepper_x1 ENABLE=1",
    "SET_STEPPER_ENABLE STEPPER=stepper_x2 ENABLE=1",

    "SET_STEPPER_ENABLE STEPPER=stepper_y ENABLE=1",
    "SET_STEPPER_ENABLE STEPPER=stepper_y1 ENABLE=1",
    "SET_STEPPER_ENABLE STEPPER=stepper_y2 ENABLE=1",

    "SET_STEPPER_ENABLE STEPPER=stepper_z ENABLE=1",
    "SET_STEPPER_ENABLE STEPPER=stepper_z1 ENABLE=1",

    # wait for planner
    "M400"
])

time.sleep(1)


# =========================================================
# PARAMETERS
# =========================================================
AMPLITUDE = 3.0

# larger step = smoother planner behavior
STEP = 0.08

POINTS = 120

# smoother synchronized movement
FEED = 2500

CHUNK = 30

t = 0.0


# =========================================================
# MAIN LOOP
# =========================================================
while True:

    cmds = []

    for _ in range(POINTS):

        # SAME waveform for all axes
        wave = AMPLITUDE * math.sin(t)

        x = wave
        y = wave
        z = wave

        cmds.append(
            f"G1 X{x:.4f} Y{y:.4f} Z{z:.4f} F{FEED}"
        )

        t += STEP

        # send trajectory chunks
        if len(cmds) >= CHUNK:

            # wait for synchronization
            cmds.append("M400")

            send_block(cmds)

            cmds = []

    if cmds:
        cmds.append("M400")
        send_block(cmds)

    time.sleep(0.02)
