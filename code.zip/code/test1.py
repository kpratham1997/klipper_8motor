import requests
import time
import math

URL = "http://127.0.0.1:7125/printer/gcode/script"

def send_block(cmds):
    requests.post(URL, json={"script": "\n".join(cmds)})


# =========================
# INIT
# =========================
send_block(["FIRMWARE_RESTART"])
time.sleep(2)

send_block([
    "MANUAL_STEPPER STEPPER=m0 GCODE_AXIS=A",
    "MANUAL_STEPPER STEPPER=m1 GCODE_AXIS=B",
    "MANUAL_STEPPER STEPPER=m2 GCODE_AXIS=C",
    "MANUAL_STEPPER STEPPER=m3 GCODE_AXIS=D",
    "G90"
])

time.sleep(0.5)


# =========================
# SMOOTH LOOP (BATCHED)
# =========================
t = 0.0

AMPLITUDE = 20
PHASE = 1.0
POINTS = 100      # number of points per batch
STEP = 0.05       # resolution
FEED = 4000       # speed

while True:
    cmds = []

    for i in range(POINTS):
        A = AMPLITUDE * math.sin(t)
        B = AMPLITUDE * math.sin(t + PHASE)
        C = AMPLITUDE * math.sin(t + 2 * PHASE)
        D = AMPLITUDE * math.sin(t + 3 * PHASE)

        cmds.append(f"G1 A{A:.2f} B{B:.2f} C{C:.2f} D{D:.2f} F{FEED}")

        t += STEP

    # 🔥 send full trajectory at once
    send_block(cmds)

    # small pause before next batch
    time.sleep(0.1)
