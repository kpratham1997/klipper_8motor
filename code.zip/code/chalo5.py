import requests
import time
import math

URL = "http://127.0.0.1:7125/printer/gcode/script"


def send_block(cmds):
    r = requests.post(
        URL,
        json={"script": "\n".join(cmds)}
    )

    print(r.status_code)


# =========================================================
# INIT
# =========================================================
send_block(["FIRMWARE_RESTART"])
time.sleep(3)

send_block([
    "SET_KINEMATIC_POSITION X=0 Y=0 Z=0",

    "G90",
    "G92 X0 Y0 Z0",

    # VERY smooth motion tuning
    "SET_VELOCITY_LIMIT ACCEL=250",
    "SET_VELOCITY_LIMIT SQUARE_CORNER_VELOCITY=1",

    # enable motors
    "SET_STEPPER_ENABLE STEPPER=stepper_x ENABLE=1",
    "SET_STEPPER_ENABLE STEPPER=stepper_x1 ENABLE=1",
    "SET_STEPPER_ENABLE STEPPER=stepper_x2 ENABLE=1",

    "SET_STEPPER_ENABLE STEPPER=stepper_y ENABLE=1",
    "SET_STEPPER_ENABLE STEPPER=stepper_y1 ENABLE=1",
    "SET_STEPPER_ENABLE STEPPER=stepper_y2 ENABLE=1",

    "SET_STEPPER_ENABLE STEPPER=stepper_z ENABLE=1",
    "SET_STEPPER_ENABLE STEPPER=stepper_z1 ENABLE=1",
])

time.sleep(1)


# =========================================================
# PARAMETERS
# =========================================================

# travel range
AMPLITUDE = 3.0

# VERY slow waveform evolution
STEP = 0.004

# huge planner buffer
POINTS = 800

# slow physical movement
FEED = 700

# big chunks = smooth planner continuity
CHUNK = 250

t = 0.0


# =========================================================
# MAIN LOOP
# =========================================================
while True:

    cmds = []

    for _ in range(POINTS):

        # synchronized smooth sine wave
        wave = AMPLITUDE * math.sin(t)

        cmds.append(
            f"G1 X{wave:.4f} Y{wave:.4f} Z{wave:.4f} F{FEED}"
        )

        t += STEP

        # large smooth trajectory streaming
        if len(cmds) >= CHUNK:
            send_block(cmds)
            cmds = []

    if cmds:
        send_block(cmds)

    # almost continuous streaming
    time.sleep(0.001)
