import requests
import time

URL = "http://127.0.0.1:7125/printer/gcode/script"

def send(cmd):
    r = requests.post(URL, json={"script": cmd})
    print(cmd, r.status_code)


# =========================
# INIT
# =========================
send("FIRMWARE_RESTART")
time.sleep(2)

# VERY IMPORTANT: map steppers → axes
send("MANUAL_STEPPER STEPPER=m0 GCODE_AXIS=A")
send("MANUAL_STEPPER STEPPER=m1 GCODE_AXIS=B")
send("MANUAL_STEPPER STEPPER=m2 GCODE_AXIS=C")
time.sleep(0.5)

# absolute mode
send("G90")
time.sleep(0.2)


# =========================
# LOOP (SYNCED MOTORS)
# =========================
while True:
    # forward wave step
    send("G1 A10 B20 C30 F1000")
    time.sleep(0.3)

    # backward
    send("G1 A0 B10 C20 F1000")
    time.sleep(0.3)
